<?php
/**
 * CK Forms default controller
 * 
 * @package    CK.Joomla
 * @subpackage Components
 * @link http://www.cookex.eu
 * @license		GNU/GPL
 */

jimport('joomla.application.component.controller');

class CkformsController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{	
		parent::display();
	}

}
?>
